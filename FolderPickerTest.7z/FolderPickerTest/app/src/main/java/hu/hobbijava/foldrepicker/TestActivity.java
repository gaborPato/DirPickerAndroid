package hu.hobbijava.foldrepicker;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import hu.hobbijava.foldrepicker.picker.DirectoryPicker;

public class TestActivity extends AppCompatActivity {

    private TextView pathTextView;
    private final String  [] PERMISSIONS = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkAppPermission();
        pathTextView = findViewById(R.id.path_text_view);
    }

    private void checkAppPermission() {
        List<String> deniedPermissionList= new ArrayList<>();
        for (String permission : PERMISSIONS) {
            if (checkSelfPermission(permission) == PackageManager.PERMISSION_DENIED){
                deniedPermissionList.add(permission);
            }

        }
        if(!deniedPermissionList.isEmpty()){
            requestPermissions(PERMISSIONS,12);
        }
    }

    public void saveClick(View view) {
        Intent i = new Intent(this, DirectoryPicker.class);
        startActivityForResult(i, DirectoryPicker.PICK_DIRECTORY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

       if (requestCode== DirectoryPicker.PICK_DIRECTORY && resultCode==RESULT_OK){

           Bundle extras = data.getExtras();
           String path= (String) extras.get(DirectoryPicker.CHOSEN_DIRECTORY);

           if (path!= null){
               pathTextView.setText("folderpath:"+path);
           }else {
               pathTextView.setText("folderpath: no selected folder");
           }


       }else {
           super.onActivityResult(requestCode,resultCode,data);
       }



    }
}
