package hu.hobbijava.foldrepicker.picker;

import android.content.Context;
import android.content.DialogInterface;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spanned;

import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.appcompat.app.AlertDialog;



class NewFolderAlertDialog {

    private NewFolderAlertDialog(){}

    static AlertDialog.Builder createDialog(Context context) {

        LinearLayout textLinLayout= new LinearLayout(context);
        textLinLayout.setOrientation(LinearLayout.VERTICAL);
        final EditText editText= new EditText(context);
        editText.setInputType(InputType.TYPE_CLASS_TEXT);
        InputFilter filter= new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
               for(int i=start ;i<end;i++){
                   if (!Character.isLetterOrDigit(source.charAt(i)) &&
                           !Character.toString(source.charAt(i)).equals("_") )
                   {
                       return "";
                   }
               }


                return null;
            }
        };

        editText.setText("NewFolder");
        editText.setFilters(new InputFilter[]{filter});
        textLinLayout.addView(editText);


        AlertDialog.Builder resultDialog= new AlertDialog.Builder(context)
                .setTitle("create new folder")
                .setView(textLinLayout)
                .setCancelable(true)
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        DirectoryPicker.createdNewFolder =null;
                    }
                })
                .setPositiveButton("create", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {



                        DirectoryPicker.createdNewFolder = editText.getText().toString();
                        dialog.dismiss();

                    }
                });


        return resultDialog;

    }
}
